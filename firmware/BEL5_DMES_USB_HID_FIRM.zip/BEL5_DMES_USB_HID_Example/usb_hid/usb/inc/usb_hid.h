/*
 * hid_main.h
 *
 *  Created on: 08.11.2017
 *      Author: Markus Lechner
 */

#ifndef USB_HID_USB_INC_USB_HID_H_
#define USB_HID_USB_INC_USB_HID_H_
/*********************************************************************FUNCTION PROTOTYPE*/
int usb_config_hid_device(void);
/**********************************************************************/
#endif /* USB_HID_USB_INC_USB_HID_H_ */

/* EOF */
